The programs were developed and ran on python 3.x.

First of all install the requirements:
pip install -r src/requirements.txt

# Standard solving

To solve the instances using SMT without rotation run the file "src/solve_smt.py"
It requires the following arguments:
- Instance: the path to either a folder containing a set of instances or a single instance in txt format
Optional arguments are:
- Timeout(-t): timeout for solving a single instance in seconds, by default this is 300 seconds
- Folder(-f): pass this flag if the Instance argument is a folder of instances

Example:
python src/solve_smt.py "./Instances" -f -t 500
This solves the instances in the folder "Instances" with a timeout of 500 seconds
The results are saved in a new folder called "out"


To solve the instances using SMT with rotation run the file "src/solve_smt_rot.py", with the same command line arguments as before

# Solving using SMTLIB

To solve a set of instances using the SMTLIB interface they first have to be dumped into an .smt2 file
To do so run the file src/other/smtlib_utils
It requires the following arguments:
- Instance: the path to either a folder containing a set of instances or a single instance in txt format
Optional arguments are:
- Folder(-f): pass this flag if the Instance argument is a folder of instances
The output will be found in a new folder called "smtlib_decl", for each instance we generate a .json and a .smt2 file
The json file contains informations about the starting value of the objective function.

To solve these SMTLIB instances we can run the "src/other/smt_opt.sh" file manually or use the "src/other/solve_smtlib.py" wrapper
This defines a command line utility to solve a set of SMTLIB instances, exactly the same as "solve_smt.py"
However with this the instances to be passed have to be .json files with a .smt2 file with the same name in the same folder


