The programs were developed and ran on python 3.x.

First of all install the requirements:
pip install -r src/requirements.txt

# Converting the instances
First of all we need to convert a set of .txt instances into a set of .mzn instances
To do so use the utility "src/Utils/convert_to_dzn.py"
It requires the following arguments:
- Instance: the path to either a folder containing a set of instances or a single instance in .txt format
Optional arguments are:
- Folder(-f): pass this flag if the Instance argument is a folder of instances
The converted instances are found in a newly created folder called "DZN_instances"

# Solving the instances

The model which solves an instance without rotations is "src/VLSI_model.mzn", the one which allows rotations is "src/VLSI_model_rotation.mzn"
Once we have the instances in .dzn format you can either run the model in the minizinc IDE or use the python command line utility we defined.

The python command line utility to solve instances is "src/Utils/solve_cp.py"
It requires the following arguments:
- Instance: the path to either a folder containing a set of instances or a single instance in .dzn format
- Model: the path to the model file
Optional arguments are:
- Timeout(-t): timeout for solving a single instance in seconds, by default this is 300 seconds
- Folder(-f): pass this flag if the Instance argument is a folder of instances

Example:
python src/Utils/solve_cp.py "Instances"  "./src/VLSI_model.mzn" -f -t 500
This solves the instances in the folder "Instances" with a timeout of 500 seconds using the given model (no rotations)

