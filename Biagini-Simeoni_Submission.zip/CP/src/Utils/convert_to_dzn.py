# Authors:
# Ildebrando Simeoni - ildebrando.simeoni@studio.unibo.it
# Diego Biagini - diego.biagini2@studio.unibo.it

import os
from pathlib import Path
from argparse import ArgumentParser
import glob

def instance_to_dzn(file_name : Path):
    f = open(file_name, "r")

    # First param is max_width
    max_width = "max_width = " + f.readline().rstrip("\n")
    # Second is number of block n_blocks
    n_blocks = "n_blocks = " + f.readline().rstrip("\n")
    # The last elements are the dimensions of the blocks
    dims = [[int(xi) for xi in x.split()] for x in f]
   

    blocks = [(w, h) for w, h in zip([el[0] for el in dims], [el[1] for el in dims])]
       
    blocks.sort(key=lambda x: x[0] * x[1], reverse=True)
        
    widths = "width = " + str([x[0] for x in blocks])
    heights = "height = " + str([x[1] for x in blocks])
        
        
    f.close()

    out_folder = Path("DZN_instances")
    out_file_name = str(file_name.stem) + '.dzn'
    out_folder.mkdir(exist_ok=True)
    
    ft = open(out_folder/out_file_name, "w")
    ft.write(max_width + ';\n' + n_blocks + ';\n' + widths + ';\n' + heights + ';\n')
    ft.close()



if __name__ == "__main__":
    parser = ArgumentParser(description='Write one or more instances in Minizinc format (.dzn)')

    parser.add_argument("instance", nargs=1, type=Path, help="Path to the instance or instance folder")
    parser.add_argument("-f", "--folder", action="store_true", help="If passed the input data will be considered a folder containing multiple instances")

    args = vars(parser.parse_args())
    simplify_list = lambda x : x[0] if isinstance(x, list) else x
    args = {k:simplify_list(args[k]) for k in args}

    # Get all instances in the folder
    if args["folder"]:
        for file in glob.glob(str(args["instance"]) + "/*.txt"):
            try:
                instance_to_dzn(Path(file))
            except Exception as e:
                logging.error(f"File:{file} is malformed\n" + str(e))
    else:
        try:
            instance_to_dzn(Path(args["instance"]))
        except Exception as e:
            logging.error(f"File:{args['instance']} is malformed\n" + str(e))