# Authors:
# Ildebrando Simeoni - ildebrando.simeoni@studio.unibo.it
# Diego Biagini - diego.biagini2@studio.unibo.it

from minizinc import Instance, Model, Solver, Status, MiniZincError
import io
import os
import time
from datetime import timedelta
import glob
from pathlib import Path
from argparse import ArgumentParser
import logging

def retrive_data(result):
    # Retrive results
    buf = io.StringIO(str(result))
    total_res = {}
    total_dim = buf.readline().split()
    total_res['max_width'] = int(total_dim[0])
    total_res['max_height'] = int(total_dim[1])
    n_blocks = buf.readline()
    total_res['n_blocks'] = int(n_blocks)

    widths = []
    heights = []
    cornerx = []
    cornery = []
    for line in buf:
        tmp = line.split()
        tmp = [int(x) for x in tmp]
        widths.append(tmp[0])
        heights.append(tmp[1])
        cornerx.append(tmp[2])
        cornery.append(tmp[3])

    total_res['widths'] = widths
    total_res['heights'] = heights
    total_res['cornerx'] = cornerx
    total_res['cornery'] = cornery
    buf.close()

    return total_res


solver_name = 'chuffed'  # 'gecode'


def solve_instance(instance_path, timeout, model_path):
    out_file_name = str(instance_path.stem) + "_out.txt"
    out_folder = Path("out/")
    out_folder.mkdir(exist_ok=True)
    
    out_file = open(out_folder / out_file_name, 'w')
    name = str(instance_path)
    vlsi = Model(str(model_path))
    vlsi.add_file(name)
    chuffed = Solver.lookup(solver_name)
    instance = Instance(chuffed, vlsi)

    start = time.time()
    try:
        result = instance.solve(timeout=timedelta(seconds=timeout))
    except MiniZincError as e:
        print(e)
    end = time.time()

    print(name + '\t' + '{:.2f}'.format(end - start))
    solve_time = result.statistics['time'].microseconds / (10 ** 6)+ result.statistics['time'].seconds
    
    if result.status is Status.UNSATISFIABLE:
        print('UNSAT')
        out_file.write('UNSAT')
        out_file.close()
    else:
        res_data = retrive_data(result)
        out_file.write(str(res_data['max_width']) + ' ' + str(res_data['max_height']) + '\n')
        out_file.write(str(res_data['n_blocks']) + '\n')
        for (w, h, cx, cy) in zip(res_data['widths'], res_data['heights'], res_data['cornerx'], res_data['cornery']):
            out_file.write(str(w) + ' ' + str(h) + ' ' + str(cx) + ' ' + str(cy) + '\n')
        out_file.close()
    return solve_time


if __name__ == "__main__":
    parser = ArgumentParser(description='Solve one or more VLSI instances using CP and chuffed solver')

    parser.add_argument("instance", nargs=1, type=Path, help="Path to the instance or instance folder (in .dzn format)")
    parser.add_argument("model", nargs=1, type=Path, help="Path to the minizinc model(.mzn) to solve the instances")
    parser.add_argument("-t", "--timeout", nargs=1, default=300, type=int, help="How many seconds to wait before timeout for each instance")
    parser.add_argument("-f", "--folder", action="store_true", help="If passed the input data will be considered a folder containing multiple instances")

    args = vars(parser.parse_args())
    simplify_list = lambda x : x[0] if isinstance(x, list) else x
    args = {k:simplify_list(args[k]) for k in args}

    # Get all instances in the folder
    if args["folder"]:
        #os.chdir(args["instance"])
        for file in glob.glob(str(args["instance"]) + "/*.dzn"):
            try:
                solve_instance(Path(file), args["timeout"], args["model"])
            except Exception as e:
                logging.error(f"File:{file} is malformed\n" + str(e))
    else:
        try:
            solve_instance(args["instance"], args["timeout"], args["model"])
        except Exception as e:
            logging.error(f"File:{args['instance']} is malformed\n" + str(e))
        