The programs were developed and ran on python 3.x.

First of all install the requirements:
pip install -r src/requirements.txt

To solve the instances using MIP without rotation run the file "src/solve_mip.py"
It requires the following arguments:
- Instance: the path to either a folder containing a set of instances or a single instance in txt format
Optional arguments are:
- Timeout(-t): timeout for solving a single instance in seconds, by default this is 300 seconds
- Folder(-f): pass this flag if the Instance argument is a folder of instances

Example:
python src/solve_mip.py "./Instances" -f -t 500
This solves the instances in the folder "Instances" with a timeout of 500 seconds
The results are saved in a new folder called "out"


To solve the instances using MIP with rotation run the file "src/solve_mip_rot.py", with the same command line arguments as before